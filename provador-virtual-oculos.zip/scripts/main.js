import {camera} from './camera.js'
import {dragOnDrop} from './GlassesControls.js'
camera()
dragOnDrop()